# Android e operação offline

O repositório tem dois pontos de entrada independentes:

| Aplicação | Código | Execução |
| --- | --- | --- |
| Painel web | `app/`, `components/`, `lib/` | Next.js: `pnpm dev` |
| Aplicativo de campo | `apps/mobile/` | Vite + React + Capacitor: `pnpm mobile:dev` |

O APK contém HTML, CSS e JavaScript compilados. Não abre uma URL remota para carregar as telas e não depende de um servidor Next.js no telefone. Não há `server.url` na configuração Capacitor. O aplicativo usa diretamente Supabase Auth, Storage e uma RPC limitada para sincronizar. Credenciais M8 e service role continuam exclusivamente no servidor web.

## Preparar o Supabase existente

No SQL Editor do **projeto novo**, execute **somente**:

[`20260910020000_mobile_offline.sql`](../supabase/migrations/20260910020000_mobile_offline.sql)

Não execute novamente a migração inicial num banco já configurado. A migração Android é aditiva: cria recibos de sincronização, funções e duas políticas de Storage com nomes próprios. Não remove dados nem políticas anteriores. Foi validada em PostgreSQL local embarcado (PGlite), incluindo as definições de tabelas da migração inicial deste repositório. Isso não substitui a validação no Supabase real.

A chave service role não permite executar SQL arbitrário pelo SDK. A alteração do banco remoto deve ser feita pelo SQL Editor ou pelo CLI com credenciais de implantação. Não há rota HTTP nova que execute SQL administrativo.

Antes de sair a campo, configure no painel web os tipos de despesa, cartões e veículos. Cadastros vazios no banco produzirão seletores vazios no APK.

## Desenvolvimento

Requisitos: Node 22+, pnpm, JDK 21 e Android SDK 36 para compilar Android. Android Studio 2025.2.1 ou posterior atende à base do Capacitor 8. As versões exatas resolvidas estão em `pnpm-lock.yaml`.

```bash
pnpm install
pnpm mobile:dev
```

Abra `http://localhost:5173`. Esse servidor é apenas uma prévia de desenvolvimento; o modo offline após reabrir depende dos recursos embarcados no APK. Não foi implementado um service worker para instalar essa prévia como PWA.

A configuração lê **apenas** `NEXT_PUBLIC_SUPABASE_URL` e `NEXT_PUBLIC_SUPABASE_ANON_KEY` do `.env.local` na raiz. Para usar outro projeto, copie `apps/mobile/.env.example` para `apps/mobile/.env.local` e preencha URL e chave pública. Não copie outras credenciais para arquivos `VITE_*`. Nunca use service role no APK.

```bash
pnpm mobile:build       # TypeScript estrito + bundle estático
pnpm mobile:test        # Persistência, fila e contrato PostgreSQL
pnpm --filter @rj/mobile exec playwright install --with-deps chromium
pnpm --filter @rj/mobile test:e2e
pnpm android:sync       # Bundle + atualização do projeto Android
pnpm --filter @rj/mobile android:open
```

O projeto Android já está em `apps/mobile/android/`; não é necessário executar `cap add` novamente. Se o Java padrão for 25, selecione JDK 21 para esse projeto: o Gradle incluído não aceita Java 25.

## Gerar e instalar APK de teste

Configure `ANDROID_HOME` para seu SDK e `JAVA_HOME` para o JDK 21. Alternativamente, deixe o Android Studio configurar o SDK em `android/local.properties` (arquivo ignorado pelo Git).

```bash
pnpm android:apk
```

Saída: `apps/mobile/android/app/build/outputs/apk/debug/app-debug.apk`.

No Windows, execute `pnpm android:sync` e depois `gradlew.bat assembleDebug` dentro de `apps/mobile/android`, ou use o Android Studio. O script `android:apk` da raiz usa o wrapper Unix.

```bash
adb install -r apps/mobile/android/app/build/outputs/apk/debug/app-debug.apk
```

Esse APK usa assinatura de desenvolvimento. Uma distribuição definitiva exige chave de assinatura própria, versionamento e validação em dispositivo físico. Mantenha o mesmo applicationId e a mesma assinatura nas atualizações para preservar os dados locais. O identificador inicial é `br.com.rjcompressores.despesas`.

## Funcionalidades desta versão

- Login por usuário ou e-mail e troca de senha no primeiro acesso.
- Reabertura offline para a última conta autenticada no aparelho.
- Cache de tipos, cartões e veículos, separado por usuário.
- Despesa com data, cliente, OS, documento, valor, pagamento, vencimento, até 48 parcelas, observação e comprovante.
- Hospedagem com check-in/check-out e abastecimento com veículo, hodômetro, litros e combustível.
- Foto via câmera do Android usando seletor de arquivos com `capture`, ou escolha de imagem/PDF. O arquivo completo é preservado localmente antes de confirmar a gravação.
- Rascunho do formulário e foto preservados ao trocar de aba.
- Início/fim de viagem offline, com horário, KM, destino, motivo e ocorrência.
- Histórico local, estados pendentes e reenvio manual.
- Retentativas automáticas com espera crescente enquanto o aplicativo estiver aberto, ao reconectar e ao voltar para o primeiro plano.

Os módulos de usuários, aprovação manual, relatórios consolidados, financeiro, ERP e backup administrativo continuam no painel web. As despesas sincronizadas entram nas mesmas tabelas e passam a aparecer nesses módulos. O app de campo não oferece edição de despesas já sincronizadas nesta versão; correções e devoluções continuam pelo painel web. Não há pagamento bancário, ERP ou aprovação administrativa offline.

## Persistência e sincronização

`src/db.ts` usa Dexie/IndexedDB no armazenamento privado da WebView. Uma transação grava registro, operação e Blob do comprovante. Nenhum `File` temporário ou URL `blob:` é tratado como comprovante persistente. Rascunhos também contêm os bytes do arquivo e não fazem upload antecipado.

`src/sync.ts` implementa uma fila por conta, bloqueio entre abas, ordenação início/fim de KM, espera crescente para falhas transitórias e retenção dos itens com erro. Uma falha num registro não apaga os demais. Uma falha de dependência impede enviar o encerramento antes do início da viagem.

`src/remote.ts` verifica a sessão antes de sincronizar. Comprovantes têm caminho determinístico `usuario/operacao/hash-do-conteudo.ext`, upload sem sobrescrita e URL assinada compatível com o painel existente. A URL usada no payload é preservada para reenvios idênticos. Arquivos locais só são removidos da fila após a confirmação do servidor.

`mobile_apply_operation` obtém o usuário de `auth.uid()`, valida perfil ativo, cartão, tipo, comprovante e veículo. A função salva as alterações e um recibo na mesma transação. Receber novamente o mesmo identificador/payload retorna o resultado anterior, sem duplicar linhas. Reutilizar o identificador com dados diferentes é rejeitado.

As parcelas são gravadas atomicamente, com distribuição dos centavos restantes. A aprovação automática considera o **total da compra** ou total por diária, nunca apenas a primeira parcela. O limite diário conta grupos distintos. O recebimento de operações móveis do mesmo usuário é serializado no servidor. As gravações do painel antigo não usam esse mesmo bloqueio e permanecem sujeitas às limitações anteriores de concorrência.

O servidor recalcula os alertas de frota após abastecimento ou conclusão de viagem, usando a faixa dos dois maiores hodômetros dos abastecimentos e viagens inteiramente contidas nela. Preserva resoluções manuais e não limpa alertas por uma viagem ainda aberta. Somente a primeira parcela carrega litros de um abastecimento para não contabilizar o mesmo volume repetidamente.

## Conflitos e limites operacionais

- O primeiro login, a troca de senha e o primeiro download de cadastros exigem internet.
- A sincronização ocorre com o app aberto/ao retornar. Não há serviço Android contínuo ou garantia de sincronização com o app encerrado.
- A disponibilidade de veículos offline é provisória. O servidor rejeita uma viagem se houver outra aberta para o usuário ou veículo. O encerramento valida dono, status, KM inicial e horário inicial; não sobrescreve uma viagem corrigida por outra pessoa.
- Um conflito preserva os dados no aparelho e exige conferência com o gestor antes de tentar novamente. Não há resolução automática que descarte ou sobrescreva dados.
- O histórico baixa até 200 despesas/parcelas e 200 viagens recentes, além das viagens ainda abertas e dos registros locais pendentes. Não é um relatório completo do banco.
- Não desinstale nem use “Limpar dados” com pendências. O IndexedDB não sobrevive a essas ações. O backup Android foi desativado para evitar cópia automática de sessão e comprovantes. Não há criptografia adicional específica do banco local ou biometria nesta versão.
- Um perfil revogado durante uma viagem offline só pode ser reconhecido ao reconectar. O servidor impede sincronização de contas inativas. Dados já baixados permanecem no aparelho até sua limpeza administrativa.
- Fotos enviadas antes de um erro de validação permanecem no Storage e na fila local para recuperação. Não há remoção automática de comprovantes órfãos.
- As políticas antigas e APIs administrativas do painel não foram redesenhadas nesta entrega. Os riscos identificados no diagnóstico inicial devem ser resolvidos antes de uma publicação ampla. O APK não utiliza essas APIs administrativas.

## Homologação no aparelho

1. Aplicar a migração Android e criar os cadastros necessários no projeto novo.
2. Instalar APK, entrar online e sincronizar cadastros.
3. Ativar modo avião; registrar despesa com câmera, fechar e reabrir o app.
4. Conferir despesa e foto pendentes; iniciar e finalizar uma viagem.
5. Reconectar com o app aberto e verificar a confirmação no aparelho e no painel web.
6. Interromper a rede durante um upload e durante uma sincronização; verificar que o reenvio não duplica registros.
7. Testar expiração da sessão, espaço insuficiente, captura cancelada e conflito entre dois aparelhos no mesmo veículo.
8. Validar aprovação, parcelamento, reembolso e alertas no painel com lançamentos originados no APK.

Referências: [Capacitor Android](https://capacitorjs.com/docs/android), [ambiente Capacitor](https://capacitorjs.com/docs/getting-started/environment-setup), [transações Dexie](https://dexie.org/docs/Dexie/Dexie.transaction()).

## Duração e lembrete de KM

A viagem aberta mostra a duração em horas, minutos e segundos, calculada a partir
 do início salvo no aparelho. O botão **Finalizar** (com ícone quadrado) abre os campos
 de encerramento. A contagem continua até confirmar **Finalizar viagem**;
 **Continuar viagem** fecha os campos sem encerrar o apontamento.

No Android, o app solicita permissão de notificações na primeira viagem aberta.
A notificação **KM em aberto** usa o cronômetro nativo do sistema e continua
 contando fora do app, sem depender de um temporizador JavaScript em segundo plano.
Ao finalizar no aparelho, ela é removida mesmo sem internet. Tocar nela abre o app,
 onde o resumo mostra a viagem aberta e o acesso à aba KM.

A tela de bloqueio depende das configurações de notificações do usuário e do
 fabricante. O canal **Viagem de KM em aberto** deve estar habilitado e autorizado
 na tela de bloqueio. Não há serviço em primeiro plano nem restauração automática
 após reiniciar o telefone ou forçar a parada: reabra o app para restaurar o lembrete.
 Algumas versões do Android permitem dispensar notificações em andamento; o app
 reapresenta o lembrete ao voltar ao primeiro plano.

Validação no telefone: iniciar uma viagem online e outra offline, autorizar/recusar
 notificações, bloquear a tela e conferir o cronômetro, sair para outro aplicativo,
 reabrir, usar Finalizar e Continuar viagem, e finalmente confirmar o KM final e conferir
 a remoção da notificação. Verificar também viagem acima de uma hora, encerramento
 sincronizado e troca de conta. O cronômetro usa o horário do aparelho.

Referência: [cronômetro e visibilidade de notificações Android](https://developer.android.com/reference/android/app/Notification.Builder).

## Observação final do KM

Antes de distribuir a versão com observação final, aplique também
`supabase/migrations/20260910030000_mobile_km_observation.sql` no SQL Editor.
Ela atualiza a RPC para salvar o campo `observacao` já existente, separado da
ocorrência. Sem essa atualização, o servidor antigo não preserva a observação
recebida do app. A opção Não deixa a ocorrência vazia; Sim exige descrição.

## Correção de despesas reprovadas

Aplicar `supabase/migrations/20260910040000_mobile_expense_resubmit.sql` antes de
usar o reenvio no APK. O app mostra a justificativa e permite ajustar e reenviar
pelo mesmo ID, preservando o comprovante existente quando não houver substituição.
Em despesas parceladas, a correção afeta somente a parcela selecionada e mantém
vencimento e agrupamento. O reenvio volta para aprovação manual, mesmo abaixo do
limite. A RPC confere proprietário, status e versão do registro; conflitos mantêm
a operação pendente para conferência, sem sobrescrever mudanças no servidor.
O formulário de correção não substitui o rascunho de uma nova despesa.
