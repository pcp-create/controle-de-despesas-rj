# Instalação do app 0.2.0

## Supabase existente

1. Abra o mesmo projeto Supabase que já atende ao painel e ao app.
2. Entre em SQL Editor → New query.
3. Cole todo o conteúdo de `docs/ATUALIZAR_SUPABASE_APP.sql` e execute.
4. Aguarde a conclusão sem erros. O arquivo reúne, na ordem correta, as três
   migrações móveis (base offline, observação final de KM e reenvio de despesas).
   Pode ser aplicado mesmo se a base offline já foi instalada. Não execute
   `20260910002000_initial_schema.sql` novamente num banco existente.

O script configura a fila idempotente no servidor, login por usuário, políticas
móveis do bucket `comprovantes`, operações de KM, observação final e correção de
despesas reprovadas. Não apaga despesas existentes. Data e hora usam os campos
existentes `data_despesa` e `hora_despesa`.

Os nomes de aprovadores/reprovadores vêm de `profiles.nome`, vinculados por
`despesas.gestor_aprovador_id`. Se a decisão não tiver responsável registrado,
o app exibe somente o status. A consulta respeita as políticas de leitura do
banco existente; o script não amplia acesso aos perfis.

Confira os cadastros no painel: usuários ativos e vinculados ao Auth, tipos de
despesa ativos, veículos e cartões associados ao usuário. Não é necessário
criar outro banco nem alterar chaves para esta atualização.

## Instalar e conferir

1. Sincronize os lançamentos pendentes da versão instalada.
2. Instale o APK de atualização sobre o app existente, sem desinstalar ou limpar
   os dados. O pacote mantém `br.com.rjcompressores.despesas` e usa a chave de
   desenvolvimento disponível neste ambiente. Se o Android rejeitar a assinatura,
   é necessário usar a mesma chave do APK anterior para preservar a instalação.
3. Abra o app com internet e toque em Sincronizar.
4. Autorize notificações e sua exibição na tela de bloqueio para o lembrete de KM.
5. Teste uma despesa com data/hora, um parcelamento, uma correção de despesa
   reprovada e um encerramento de KM com observação/ocorrência. Confira no painel.

A correção mantém o ID da despesa e, em compras parceladas, afeta a parcela
selecionada. O reenvio volta para aprovação manual. O lembrete de KM usa o
cronômetro Android; reinício do aparelho ou parada forçada exige reabrir o app.
A validação automatizada não substitui conferir câmera, notificações e bloqueio
de tela em um telefone real.
